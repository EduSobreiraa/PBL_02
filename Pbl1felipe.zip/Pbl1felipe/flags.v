
//Flag de erro
module error_detector (
    input ov1, input ov2, input ov3, output err_out
);
    wire or1;
    or (or1, ov1, ov2);
    or (err_out, or1, ov3);
endmodule

//flag de 0
module zero_detector_16bit (
    input [15:0] in_val,
    output is_zero
);
    nor (is_zero, 
        in_val[0],  in_val[1],  in_val[2],  in_val[3],
        in_val[4],  in_val[5],  in_val[6],  in_val[7],
        in_val[8],  in_val[9],  in_val[10], in_val[11],
        in_val[12], in_val[13], in_val[14], in_val[15]
    );
endmodule

//controlador das flags
module flags_controller (
    input ov_in, input z_in, input cout_in, input err_in,
    output led_ov, output led_z, output led_cout, output led_err
);
    supply0 gnd;
    or (led_ov, ov_in, gnd);
    or (led_z, z_in, gnd);
    or (led_cout, cout_in, gnd);
    or (led_err, err_in, gnd);
endmodule

/*
    wire flag_err_val;
    error_detector check_err (
        .ov1(ovf_5x),
        .ov2(ovf_m5x),
        .ov3(ovf_y),
        .err_out(flag_err_val)
    );

    flags_controller out_flags (
        .ov_in(ovf_y),
        .z_in(flag_zero_val),
        .cout_in(cout_y),
        .err_in(flag_err_val),
        .led_ov(ledr[0]),
        .led_z(ledr[1]),
        .led_cout(ledr[2]),
        .led_err(ledr[3])
    );
    
    or (ledr[4], gnd, gnd);
    or (ledr[5], gnd, gnd);
    or (ledr[6], gnd, gnd);
    or (ledr[7], gnd, gnd);
    or (ledr[8], gnd, gnd);
    or (ledr[9], gnd, gnd);

endmodule*/
