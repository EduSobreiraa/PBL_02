module top_module (
    input wire [9:0] sw,      // Entradas pelas chaves: sw[7:0] é o valor X, sw[8] seleciona exibição de X ou Equação, sw[9] seleciona Hex ou Dec
    output wire [9:0] ledr,  // Leds de saída para flags (overflow, zero, carry, erro)
    output wire [6:0] hex0,  // Displays de 7 segmentos para a visualização dos valores
    output wire [6:0] hex1,
    output wire [6:0] hex2,
    output wire [6:0] hex3,
    output wire [6:0] hex4,
    output wire [6:0] hex5
);
    // Sinais fixos de nível lógico 0 (gnd) e 1 (vcc) para uso nas conexões
    supply0 gnd; 
    supply1 vcc;

// Cálculo de 5x (1x + 4x) através de deslocamento de bits
    wire [15:0] val_5x;
    wire cout_5x, ovf_5x;
    adder_16bit add_5x_inst (
		// 1x com extensão do bit de sinal
        .a({sw[7], sw[7], sw[7], sw[7], sw[7], sw[7], sw[7], sw[7], sw[7], sw[6], sw[5], sw[4], sw[3], sw[2], sw[1], sw[0]}), 
		 //4 (deslocado 2 bits para esquerda)
        .b({sw[7], sw[7], sw[7], sw[7], sw[7], sw[7], sw[7], sw[6], sw[5], sw[4], sw[3], sw[2], sw[1], sw[0], gnd, gnd}),       
        .cin(gnd),
        .sum(val_5x), .cout(cout_5x), .overflow(ovf_5x)
    );

// Inversão de 5x para o complemento de 2.
    wire [15:0] not_5x;
    not (not_5x[0], val_5x[0]);   not (not_5x[1], val_5x[1]);   not (not_5x[2], val_5x[2]);   not (not_5x[3], val_5x[3]);
    not (not_5x[4], val_5x[4]);   not (not_5x[5], val_5x[5]);   not (not_5x[6], val_5x[6]);   not (not_5x[7], val_5x[7]);
    not (not_5x[8], val_5x[8]);   not (not_5x[9], val_5x[9]);   not (not_5x[10], val_5x[10]); not (not_5x[11], val_5x[11]);
    not (not_5x[12], val_5x[12]); not (not_5x[13], val_5x[13]); not (not_5x[14], val_5x[14]); not (not_5x[15], val_5x[15]);

// Soma de +1 (via cin=vcc) para completar o complemento de 2 de 5x E soma direta da constante 6 0000 0000 0000 0110
    wire [15:0] sum_m5x_6;
    wire cout_m5x, ovf_m5x;
    adder_16bit add_m5x_inst (
        .a(not_5x),
        .b({gnd, gnd, gnd, gnd, gnd, gnd, gnd, gnd, gnd, gnd, gnd, gnd, gnd, vcc, vcc, gnd}), //Constante 6
        .cin(vcc), // cin = 1, para o +1 do complemento de 2
        .sum(sum_m5x_6), .cout(cout_m5x), .overflow(ovf_m5x)
    );

// Cálculo o módulo de X para usar na multiplicação sem sinal
    wire [7:0] x_inv, x_neg, x_abs;
    wire c_x1, c_x2, c_x3, c_x4, c_x5, c_x6, c_x7, c_x8;

    // Inverte os bits da entrada sw[7:0]
    not (x_inv[0], sw[0]); not (x_inv[1], sw[1]); not (x_inv[2], sw[2]); not (x_inv[3], sw[3]);
    not (x_inv[4], sw[4]); not (x_inv[5], sw[5]); not (x_inv[6], sw[6]); not (x_inv[7], sw[7]);

    // Soma +1 bit a bit para obter o valor negativo de X em complemento de 2
    full_adder fa_x0 (.a(x_inv[0]), .b(gnd), .cin(vcc),  .sum(x_neg[0]), .cout(c_x1));
    full_adder fa_x1 (.a(x_inv[1]), .b(gnd), .cin(c_x1), .sum(x_neg[1]), .cout(c_x2));
    full_adder fa_x2 (.a(x_inv[2]), .b(gnd), .cin(c_x2), .sum(x_neg[2]), .cout(c_x3));
    full_adder fa_x3 (.a(x_inv[3]), .b(gnd), .cin(c_x3), .sum(x_neg[3]), .cout(c_x4));
    full_adder fa_x4 (.a(x_inv[4]), .b(gnd), .cin(c_x4), .sum(x_neg[4]), .cout(c_x5));
    full_adder fa_x5 (.a(x_inv[5]), .b(gnd), .cin(c_x5), .sum(x_neg[5]), .cout(c_x6));
    full_adder fa_x6 (.a(x_inv[6]), .b(gnd), .cin(c_x6), .sum(x_neg[6]), .cout(c_x7));
    full_adder fa_x7 (.a(x_inv[7]), .b(gnd), .cin(c_x7), .sum(x_neg[7]), .cout(c_x8));

    // Se sw[7]=1 (negativo), seleciona x_neg; se sw[7]=0 (positivo), seleciona a entrada original sw
    mux2_1 mx0 (.d0(sw[0]), .d1(x_neg[0]), .sel(sw[7]), .y(x_abs[0]));
    mux2_1 mx1 (.d0(sw[1]), .d1(x_neg[1]), .sel(sw[7]), .y(x_abs[1]));
    mux2_1 mx2 (.d0(sw[2]), .d1(x_neg[2]), .sel(sw[7]), .y(x_abs[2]));
    mux2_1 mx3 (.d0(sw[3]), .d1(x_neg[3]), .sel(sw[7]), .y(x_abs[3]));
    mux2_1 mx4 (.d0(sw[4]), .d1(x_neg[4]), .sel(sw[7]), .y(x_abs[4]));
    mux2_1 mx5 (.d0(sw[5]), .d1(x_neg[5]), .sel(sw[7]), .y(x_abs[5]));
    mux2_1 mx6 (.d0(sw[6]), .d1(x_neg[6]), .sel(sw[7]), .y(x_abs[6]));
    mux2_1 mx7 (.d0(sw[7]), .d1(x_neg[7]), .sel(sw[7]), .y(x_abs[7]));

// Geração dos 8 produtos parciais multiplicando o vetor x_abs por cada um dos seus bits
    wire [7:0] pp0_and, pp1_and, pp2_and, pp3_and, pp4_and, pp5_and, pp6_and, pp7_and;

    pp_gen_8bit gen_pp0 (.a(x_abs), .b(x_abs[0]), .y(pp0_and));
    pp_gen_8bit gen_pp1 (.a(x_abs), .b(x_abs[1]), .y(pp1_and));
    pp_gen_8bit gen_pp2 (.a(x_abs), .b(x_abs[2]), .y(pp2_and));
    pp_gen_8bit gen_pp3 (.a(x_abs), .b(x_abs[3]), .y(pp3_and));
    pp_gen_8bit gen_pp4 (.a(x_abs), .b(x_abs[4]), .y(pp4_and));
    pp_gen_8bit gen_pp5 (.a(x_abs), .b(x_abs[5]), .y(pp5_and));
    pp_gen_8bit gen_pp6 (.a(x_abs), .b(x_abs[6]), .y(pp6_and));
    pp_gen_8bit gen_pp7 (.a(x_abs), .b(x_abs[7]), .y(pp7_and));

// Soma dos produtos parciais com alinhamento de bits para calcular x²
    wire [15:0] s_pp01, s_pp23, s_pp45, s_pp67, s_pp0123, s_pp4567, x_squared;

    // Soma do produto parcial 0 com o produto parcial 1 deslocado em 1 bit
    adder_16bit add_pp01 (
        .a({gnd, gnd, gnd, gnd, gnd, gnd, gnd, gnd, pp0_and[7], pp0_and[6], pp0_and[5], pp0_and[4], pp0_and[3], pp0_and[2], pp0_and[1], pp0_and[0]}), 
        .b({gnd, gnd, gnd, gnd, gnd, gnd, gnd, pp1_and[7], pp1_and[6], pp1_and[5], pp1_and[4], pp1_and[3], pp1_and[2], pp1_and[1], pp1_and[0], gnd}), 
        .cin(gnd), .sum(s_pp01)
    );
    
    // Soma do produto parcial 2 deslocado 2 bits com o produto parcial 3 deslocado 3 bits
    adder_16bit add_pp23 (
        .a({gnd, gnd, gnd, gnd, gnd, gnd, pp2_and[7], pp2_and[6], pp2_and[5], pp2_and[4], pp2_and[3], pp2_and[2], pp2_and[1], pp2_and[0], gnd, gnd}), 
        .b({gnd, gnd, gnd, gnd, gnd, pp3_and[7], pp3_and[6], pp3_and[5], pp3_and[4], pp3_and[3], pp3_and[2], pp3_and[1], pp3_and[0], gnd, gnd, gnd}), 
        .cin(gnd), .sum(s_pp23)
    );
    
    // Soma do produto parcial 4 deslocado 4 bits com o produto parcial 5 deslocado 5 bits
    adder_16bit add_pp45 (
        .a({gnd, gnd, gnd, gnd, pp4_and[7], pp4_and[6], pp4_and[5], pp4_and[4], pp4_and[3], pp4_and[2], pp4_and[1], pp4_and[0], gnd, gnd, gnd, gnd}), 
        .b({gnd, gnd, gnd, pp5_and[7], pp5_and[6], pp5_and[5], pp5_and[4], pp5_and[3], pp5_and[2], pp5_and[1], pp5_and[0], gnd, gnd, gnd, gnd, gnd}), 
        .cin(gnd), .sum(s_pp45)
    );
    
    // Soma do produto parcial 6 deslocado 6 bits com o produto parcial 7 deslocado 7 bits
    adder_16bit add_pp67 (
        .a({gnd, gnd, pp6_and[7], pp6_and[6], pp6_and[5], pp6_and[4], pp6_and[3], pp6_and[2], pp6_and[1], pp6_and[0], gnd, gnd, gnd, gnd, gnd, gnd}), 
        .b({gnd, pp7_and[7], pp7_and[6], pp7_and[5], pp7_and[4], pp7_and[3], pp7_and[2], pp7_and[1], pp7_and[0], gnd, gnd, gnd, gnd, gnd, gnd, gnd}), 
        .cin(gnd), .sum(s_pp67)
    );

    // Estrutura em árvore para somar os resultados intermediários até obter x_squared
    adder_16bit add_p0123 (.a(s_pp01), .b(s_pp23), .cin(gnd), .sum(s_pp0123));
    adder_16bit add_p4567 (.a(s_pp45), .b(s_pp67), .cin(gnd), .sum(s_pp4567));
    adder_16bit add_x2    (.a(s_pp0123), .b(s_pp4567), .cin(gnd), .sum(x_squared));

// Cálculo final da equação: junta x² com (-5x + 6) entregando o resultado final em y_val
    wire [15:0] y_val;
    wire cout_y, ovf_y;
    adder_16bit add_y (.a(x_squared), .b(sum_m5x_6), .cin(gnd), .sum(y_val), .cout(cout_y), .overflow(ovf_y));

// Muxes de seleção de exibição: se sw[8]=0 envia o resultado da equação (y_val), 
// Se sw[8]=1 envia a entrada X com extensão de sinal
    wire [15:0] disp_val;
    mux2_1 mux_d0  (.d0(y_val[0]),  .d1(sw[0]), .sel(sw[8]), .y(disp_val[0]));
    mux2_1 mux_d1  (.d0(y_val[1]),  .d1(sw[1]), .sel(sw[8]), .y(disp_val[1]));
    mux2_1 mux_d2  (.d0(y_val[2]),  .d1(sw[2]), .sel(sw[8]), .y(disp_val[2]));
    mux2_1 mux_d3  (.d0(y_val[3]),  .d1(sw[3]), .sel(sw[8]), .y(disp_val[3]));
    mux2_1 mux_d4  (.d0(y_val[4]),  .d1(sw[4]), .sel(sw[8]), .y(disp_val[4]));
    mux2_1 mux_d5  (.d0(y_val[5]),  .d1(sw[5]), .sel(sw[8]), .y(disp_val[5]));
    mux2_1 mux_d6  (.d0(y_val[6]),  .d1(sw[6]), .sel(sw[8]), .y(disp_val[6]));
    mux2_1 mux_d7  (.d0(y_val[7]),  .d1(sw[7]), .sel(sw[8]), .y(disp_val[7]));
    
    // Extensão de sinal do bit sw[7] para os bits superiores caso X seja selecionado
    mux2_1 mux_d8  (.d0(y_val[8]),  .d1(sw[7]), .sel(sw[8]), .y(disp_val[8]));
    mux2_1 mux_d9  (.d0(y_val[9]),  .d1(sw[7]), .sel(sw[8]), .y(disp_val[9]));
    mux2_1 mux_d10 (.d0(y_val[10]), .d1(sw[7]), .sel(sw[8]), .y(disp_val[10]));
    mux2_1 mux_d11 (.d0(y_val[11]), .d1(sw[7]), .sel(sw[8]), .y(disp_val[11]));
    mux2_1 mux_d12 (.d0(y_val[12]), .d1(sw[7]), .sel(sw[8]), .y(disp_val[12]));
    mux2_1 mux_d13 (.d0(y_val[13]), .d1(sw[7]), .sel(sw[8]), .y(disp_val[13]));
    mux2_1 mux_d14 (.d0(y_val[14]), .d1(sw[7]), .sel(sw[8]), .y(disp_val[14]));
    mux2_1 mux_d15 (.d0(y_val[15]), .d1(sw[7]), .sel(sw[8]), .y(disp_val[15]));

// Tratamento e exibição do valor final nos displays de 7 segmentos
    wire [15:0] abs_out_val;
    wire [19:0] bcd_out;

    // Calcula o valor absoluto para a conversão Decimal/BCD conseguir processar sem sinal
    abs_16bit modulo_abs (.in_val(disp_val), .out_abs(abs_out_val));
    
    // Converte o valor absoluto em dígitos BCD
    bin_to_bcd_16 modulo_bcd (.bin_in(abs_out_val), .bcd_out(bcd_out));
    
    // Lógica para acionar o sinal negativo (-) APENAS SE: 
    // - sw[8] for 1 (Exibindo X)
    // - sw[9] for 0 (Modo Decimal)
    // - sw[7] for 1 (Valor de X é negativo)
    wire not_sw9_val, sel_x_dec, show_minus_flag;
    not (not_sw9_val, sw[9]);
    and (sel_x_dec, sw[8], not_sw9_val);
    and (show_minus_flag, sel_x_dec, sw[7]);

    // Controla a exibição nos displays trocando entre Hexadecimal e Decimal baseado na chave sw[9]
    display_controller modulo_displays (
        .bcd_in(bcd_out),
        .hex_val_in(disp_val), 
        .sel_hex(sw[9]),
        .show_minus(show_minus_flag), // Passa a flag de sinal para o controlador       
        .hex0(hex0), .hex1(hex1), .hex2(hex2),
        .hex3(hex3), .hex4(hex4), .hex5(hex5)
    );

// Verificação de condições e geração dos LEDs de sinalização
    wire flag_zero_val;
    // Checa se o valor final a ser exibido é exatamente zero
    zero_detector_16bit check_zero (
        .in_val(disp_val), 
        .is_zero(flag_zero_val)
    );

    wire flag_err_val;
    // O sinal ERR verifica se houve overflow em qualquer uma das adições intermediárias do sistema
    error_detector check_err (
        .ov1(ovf_5x),
        .ov2(ovf_m5x),
        .ov3(ovf_y),
        .err_out(flag_err_val)
    );

    // Envia o estado das flags para os leds 0 a 3 da placa
    flags_controller out_flags (
        .ov_in(ovf_y),
        .z_in(flag_zero_val),
        .cout_in(cout_y),
        .err_in(flag_err_val),
        .led_ov(ledr[0]), 
        .led_z(ledr[1]),
        .led_cout(ledr[2]),
        .led_err(ledr[3])
    );
    
    // Todos os outros leds não utilizados permaneçam desligados
    or (ledr[4], gnd, gnd);
    or (ledr[5], gnd, gnd);
    or (ledr[6], gnd, gnd);
    or (ledr[7], gnd, gnd);
    or (ledr[8], gnd, gnd);
    or (ledr[9], gnd, gnd);

endmodule

// produto parcial multiplicando todos os bits A pelo bit individual B

module pp_gen_8bit (
    input [7:0] a,
    input b,
    output [7:0] y
);
    // Multiplicação bit a bit 
    and (y[0], a[0], b);
    and (y[1], a[1], b);
    and (y[2], a[2], b);
    and (y[3], a[3], b);
    and (y[4], a[4], b);
    and (y[5], a[5], b);
    and (y[6], a[6], b);
    and (y[7], a[7], b);
endmodule


