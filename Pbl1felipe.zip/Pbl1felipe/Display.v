// Decodificador Hexadecimal para 7 segmentos
module hex_7seg (
    input w, x, y, z, output a, b, c, d, e, f, g
);
    // Inversão dos bits de entrada
    wire nw, nx, ny, nz;
    not (nw, w); not (nx, x); not (ny, y); not (nz, z);
    
    // Geração dos mintermos, mo a m15, 0 a F
    wire m0, m1, m2, m3, m4, m5, m6, m7, m8, m9, m10, m11, m12, m13, m14, m15;
    and (m0, nw, nx, ny, nz);
    and (m1, nw, nx, ny, z);
    and (m2, nw, nx, y, nz);
    and (m3, nw, nx, y, z);
    and (m4, nw, x, ny, nz);
    and (m5, nw, x, ny, z);
    and (m6, nw, x, y, nz);
    and (m7, nw, x, y, z);
    and (m8, w, nx, ny, nz);
    and (m9, w, nx, ny, z);
    and (m10, w, nx, y, nz);
    and (m11, w, nx, y, z);
    and (m12, w, x, ny, nz);
    and (m13, w, x, ny, z);
    and (m14, w, x, y, nz);
    and (m15, w, x, y, z);
    
    // Junção dos mintermos via portas NOR para cada segmento
    nor (a, m0, m2, m3, m5, m6, m7, m8, m9, m10, m12, m14, m15);
    nor (b, m0, m1, m2, m3, m4, m7, m8, m9, m10, m13);
    nor (c, m0, m1, m3, m4, m5, m6, m7, m8, m9, m10, m11, m13);
    nor (d, m0, m2, m3, m5, m6, m8, m9, m11, m12, m13, m14);
    nor (e, m0, m2, m6, m8, m10, m11, m12, m13, m14, m15);
    nor (f, m0, m4, m5, m6, m8, m9, m10, m11, m12, m14, m15);
    nor (g, m2, m3, m4, m5, m6, m8, m9, m10, m11, m13, m14, m15);
endmodule

// Módulo para manter o display inteiramente desligado
module off_7seg (
    output a, b, c, d, e, f, g
);
    supply0 gnd;
    not (a, gnd); 
    not (b, gnd); 
    not (c, gnd); 
    not (d, gnd);
    not (e, gnd); 
    not (f, gnd); 
    not (g, gnd);
endmodule

// Controlador principal dos displays de 7 segmentos BCD ou HEX
module display_controller (
    input [19:0] bcd_in,
    input [15:0] hex_val_in,
    input sel_hex,
    input show_minus, // controla a aparição do sinal negativo
    output [6:0] hex0,
    output [6:0] hex1,
    output [6:0] hex2,
    output [6:0] hex3,
    output [6:0] hex4,
    output [6:0] hex5
);
    // Geração dos segmentos em decimal
    wire [6:0] dec_hex0, dec_hex1, dec_hex2, dec_hex3, dec_hex4;
    bcd_7seg disp_u   (.w(bcd_in[3]),  .x(bcd_in[2]),  .y(bcd_in[1]),  .z(bcd_in[0]),  .a(dec_hex0[0]), .b(dec_hex0[1]), .c(dec_hex0[2]), .d(dec_hex0[3]), .e(dec_hex0[4]), .f(dec_hex0[5]), .g(dec_hex0[6]));
    bcd_7seg disp_t   (.w(bcd_in[7]),  .x(bcd_in[6]),  .y(bcd_in[5]),  .z(bcd_in[4]),  .a(dec_hex1[0]), .b(dec_hex1[1]), .c(dec_hex1[2]), .d(dec_hex1[3]), .e(dec_hex1[4]), .f(dec_hex1[5]), .g(dec_hex1[6]));
    bcd_7seg disp_h   (.w(bcd_in[11]), .x(bcd_in[10]), .y(bcd_in[9]),  .z(bcd_in[8]),  .a(dec_hex2[0]), .b(dec_hex2[1]), .c(dec_hex2[2]), .d(dec_hex2[3]), .e(dec_hex2[4]), .f(dec_hex2[5]), .g(dec_hex2[6]));
    bcd_7seg disp_th  (.w(bcd_in[15]), .x(bcd_in[14]), .y(bcd_in[13]), .z(bcd_in[12]), .a(dec_hex3[0]), .b(dec_hex3[1]), .c(dec_hex3[2]), .d(dec_hex3[3]), .e(dec_hex3[4]), .f(dec_hex3[5]), .g(dec_hex3[6]));
    bcd_7seg disp_tth (.w(bcd_in[19]), .x(bcd_in[18]), .y(bcd_in[17]), .z(bcd_in[16]), .a(dec_hex4[0]), .b(dec_hex4[1]), .c(dec_hex4[2]), .d(dec_hex4[3]), .e(dec_hex4[4]), .f(dec_hex4[5]), .g(dec_hex4[6]));

    // Geração dos segmentos em hexadecimal, displays 4 e 5 sempre desligados
    wire [6:0] hx_hex0, hx_hex1, hx_hex2, hx_hex3, hx_hex4;
    hex_7seg hex_u  (.w(hex_val_in[3]),  .x(hex_val_in[2]),  .y(hex_val_in[1]),  .z(hex_val_in[0]),  .a(hx_hex0[0]), .b(hx_hex0[1]), .c(hx_hex0[2]), .d(hx_hex0[3]), .e(hx_hex0[4]), .f(hx_hex0[5]), .g(hx_hex0[6]));
    hex_7seg hex_t  (.w(hex_val_in[7]),  .x(hex_val_in[6]),  .y(hex_val_in[5]),  .z(hex_val_in[4]),  .a(hx_hex1[0]), .b(hx_hex1[1]), .c(hx_hex1[2]), .d(hx_hex1[3]), .e(hx_hex1[4]), .f(hx_hex1[5]), .g(hx_hex1[6]));
    hex_7seg hex_h  (.w(hex_val_in[11]), .x(hex_val_in[10]), .y(hex_val_in[9]),  .z(hex_val_in[8]),  .a(hx_hex2[0]), .b(hx_hex2[1]), .c(hx_hex2[2]), .d(hx_hex2[3]), .e(hx_hex2[4]), .f(hx_hex2[5]), .g(hx_hex2[6]));
    hex_7seg hex_th (.w(hex_val_in[15]), .x(hex_val_in[14]), .y(hex_val_in[13]), .z(hex_val_in[12]), .a(hx_hex3[0]), .b(hx_hex3[1]), .c(hx_hex3[2]), .d(hx_hex3[3]), .e(hx_hex3[4]), .f(hx_hex3[5]), .g(hx_hex3[6]));
    off_7seg hex_tth_off (.a(hx_hex4[0]), .b(hx_hex4[1]), .c(hx_hex4[2]), .d(hx_hex4[3]), .e(hx_hex4[4]), .f(hx_hex4[5]), .g(hx_hex4[6]));

    // Multiplexadores finais estruturais selecionando qual sinal exibir
    mux_7bit m_hex0 (.d0(dec_hex0), .d1(hx_hex0), .sel(sel_hex), .y(hex0));
    mux_7bit m_hex1 (.d0(dec_hex1), .d1(hx_hex1), .sel(sel_hex), .y(hex1));
    mux_7bit m_hex2 (.d0(dec_hex2), .d1(hx_hex2), .sel(sel_hex), .y(hex2));
    mux_7bit m_hex3 (.d0(dec_hex3), .d1(hx_hex3), .sel(sel_hex), .y(hex3));
    mux_7bit m_hex4 (.d0(dec_hex4), .d1(hx_hex4), .sel(sel_hex), .y(hex4));

    // Lógica para o Display 5: Exibe o sinal de menos se a flag show_minus for 1, caso contrário, mantém desligado
    wire [6:0] out_off, out_minus;
    off_7seg disp_off (
        .a(out_off[0]), .b(out_off[1]), .c(out_off[2]), .d(out_off[3]), .e(out_off[4]), .f(out_off[5]), .g(out_off[6])
    );
    minus_7seg disp_minus (
        .a(out_minus[0]), .b(out_minus[1]), .c(out_minus[2]), .d(out_minus[3]), .e(out_minus[4]), .f(out_minus[5]), .g(out_minus[6])
    );
    
    // Multiplexa entre desligado, ou sinal de menos
    mux_7bit m_hex5 (.d0(out_off), .d1(out_minus), .sel(show_minus), .y(hex5));
endmodule

// Exibe o sinal negativo no display (apenas o segmento g é acionado em 0)
module minus_7seg (
    output a, b, c, d, e, f, g
);
    supply0 gnd;
    supply1 vcc;
    not (a, gnd); // Desligado = 1
    not (b, gnd);
    not (c, gnd); 
    not (d, gnd); 
    not (e, gnd); 
    not (f, gnd); 
    not (g, vcc); // Ligado = 0
endmodule