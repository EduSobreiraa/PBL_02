//meio somador
module half_adder (
    input  wire a, input  wire b, output wire sum, output wire carry
);
    xor g_xor (sum, a, b);
    and g_and (carry, a, b);
endmodule


//somador completo
module full_adder (
    input  wire a, input  wire b, input  wire cin, output wire sum, output wire cout
);
    wire w_sum1, w_c1, w_c2;
//Primeiro meio somador
    half_adder ha1 (.a(a), .b(b), .sum(w_sum1), .carry(w_c1));
//Segundo meio somador
    half_adder ha2 (.a(w_sum1), .b(cin), .sum(sum), .carry(w_c2));
//Cout final
    or g_or (cout, w_c1, w_c2);
endmodule

//somador de 16bits
module adder_16bit (
    input  wire [15:0] a, input  wire [15:0] b, input  wire cin,
    output wire [15:0] sum, output wire cout, output wire overflow
);
    wire c1, c2, c3, c4, c5, c6, c7, c8, c9, c10, c11, c12, c13, c14, c15;

//Chama somadores para os bits do 0 ao 15, substituível por generate for?
    full_adder fa_0  (.a(a[0]),  .b(b[0]),  .cin(cin), .sum(sum[0]),  .cout(c1));
    full_adder fa_1  (.a(a[1]),  .b(b[1]),  .cin(c1),  .sum(sum[1]),  .cout(c2));
    full_adder fa_2  (.a(a[2]),  .b(b[2]),  .cin(c2),  .sum(sum[2]),  .cout(c3));
    full_adder fa_3  (.a(a[3]),  .b(b[3]),  .cin(c3),  .sum(sum[3]),  .cout(c4));
    full_adder fa_4  (.a(a[4]),  .b(b[4]),  .cin(c4),  .sum(sum[4]),  .cout(c5));
    full_adder fa_5  (.a(a[5]),  .b(b[5]),  .cin(c5),  .sum(sum[5]),  .cout(c6));
    full_adder fa_6  (.a(a[6]),  .b(b[6]),  .cin(c6),  .sum(sum[6]),  .cout(c7));
    full_adder fa_7  (.a(a[7]),  .b(b[7]),  .cin(c7),  .sum(sum[7]),  .cout(c8));
    full_adder fa_8  (.a(a[8]),  .b(b[8]),  .cin(c8),  .sum(sum[8]),  .cout(c9));
    full_adder fa_9  (.a(a[9]),  .b(b[9]),  .cin(c9),  .sum(sum[9]),  .cout(c10));
    full_adder fa_10 (.a(a[10]), .b(b[10]), .cin(c10), .sum(sum[10]), .cout(c11));
    full_adder fa_11 (.a(a[11]), .b(b[11]), .cin(c11), .sum(sum[11]), .cout(c12));
    full_adder fa_12 (.a(a[12]), .b(b[12]), .cin(c12), .sum(sum[12]), .cout(c13));
    full_adder fa_13 (.a(a[13]), .b(b[13]), .cin(c13), .sum(sum[13]), .cout(c14));
    full_adder fa_14 (.a(a[14]), .b(b[14]), .cin(c14), .sum(sum[14]), .cout(c15));
    full_adder fa_15 (.a(a[15]), .b(b[15]), .cin(c15), .sum(sum[15]), .cout(cout));
    xor g_overflow (overflow, c15, cout);
endmodule


