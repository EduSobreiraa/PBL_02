module adder_16bit (
    input  wire [15:0] a,
    input  wire [15:0] b,
    input  wire        cin,
    output wire [15:0] sum,
    output wire        cout,
    output wire        overflow
);

    wire [16:0] c;
    
    // Conexão do carry de entrada no primeiro bit do vetor sem usar assign
    full_adder fa_lsb (
        .a(a[0]),
        .b(b[0]),
        .cin(cin),
        .sum(sum[0]),
        .cout(c[1])
    );

    // Encadeamento do bit 1 ao 15
    genvar i;
    generate
        for (i = 1; i < 16; i = i + 1) begin : adder_chain
            full_adder fa (
                .a(a[i]),
                .b(b[i]),
                .cin(c[i]),
                .sum(sum[i]),
                .cout(c[i+1])
            );
        end
    endgenerate

    // Saída de cout sem usar assign (conectando o último fio do vetor)
    // Se a ferramenta exigir ligação de pino, pode-se usar uma porta buffer nativa:
    buf g_cout (cout, c[16]);

    // Flag de overflow puramente estrutural com primitiva XOR
    xor g_overflow (overflow, c[15], c[16]);

endmodule
