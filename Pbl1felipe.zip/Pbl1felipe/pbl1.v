module adder_16bit (
    input  wire [15:0] a,
    input  wire [15:0] b,
    input  wire        cin,
    output wire [15:0] sum,
    output wire        cout,
    output wire        overflow
);

    wire [16:0] c;
    
    // Conexão do carry de entrada no primeiro bit do vetor sem usar assign
    full_adder fa_lsb (
        .a(a[0]),
        .b(b[0]),
        .cin(cin),
        .sum(sum[0]),
        .cout(c[1])
    );

    // Encadeamento do bit 1 ao 15
    genvar i;
    generate
        for (i = 1; i < 16; i = i + 1) begin : adder_chain
            full_adder fa (
                .a(a[i]),
                .b(b[i]),
                .cin(c[i]),
                .sum(sum[i]),
                .cout(c[i+1])
            );
        end
    endgenerate

    // Saída de cout sem usar assign (conectando o último fio do vetor)
    // Se a ferramenta exigir ligação de pino, pode-se usar uma porta buffer nativa:
    buf g_cout (cout, c[16]);

    // Flag de overflow puramente estrutural com primitiva XOR
    xor g_overflow (overflow, c[15], c[16]);

endmodule

module full_adder (
    input  wire a,
    input  wire b,
    input  wire cin,
    output wire sum,
    output wire cout
);

    // Sinais internos de conexão
    wire w_sum1;
    wire w_c1;
    wire w_c2;

    // Instanciação do primeiro Half Adder
    half_adder ha1 (
        .a(a),
        .b(b),
        .sum(w_sum1),
        .carry(w_c1)
    );

    // Instanciação do segundo Half Adder
    half_adder ha2 (
        .a(w_sum1),
        .b(cin),
        .sum(sum),
        .carry(w_c2)
    );

    // Porta OR para determinar o carry out
    or g_or (cout, w_c1, w_c2);

endmodule

module half_adder (
    input  wire a,
    input  wire b,
    output wire sum,
    output wire carry
);

    // Instanciação de portas lógicas primitivas
    xor g_xor (sum, a, b);
    and g_and (carry, a, b);

endmodule

module top_module (
    input  wire [7:0] sw,
    output wire [6:0] hex0,
    output wire [6:0] hex1,
    output wire [6:0] hex2,
    output wire [6:0] hex3
);
    supply0 gnd;
    supply1 vcc;

    // --- Extensão de Sinal de 8 para 16 bits ---
    wire [15:0] a_ext;
    buf (a_ext[0], sw[0]);
    buf (a_ext[1], sw[1]);
    buf (a_ext[2], sw[2]);
    buf (a_ext[3], sw[3]);
    buf (a_ext[4], sw[4]);
    buf (a_ext[5], sw[5]);
    buf (a_ext[6], sw[6]);
    buf (a_ext[7], sw[7]);
    // Replica o MSB para manter o sinal
    buf (a_ext[8], sw[7]);
    buf (a_ext[9], sw[7]);
    buf (a_ext[10], sw[7]);
    buf (a_ext[11], sw[7]);
    buf (a_ext[12], sw[7]);
    buf (a_ext[13], sw[7]);
    buf (a_ext[14], sw[7]);
    buf (a_ext[15], sw[7]);

    // --- Constante 5 em 16 bits (0000000000000101) ---
    wire [15:0] b_ext;
    buf (b_ext[0], vcc);
    buf (b_ext[1], gnd);
    buf (b_ext[2], vcc);
    genvar i;
    generate
        for(i = 3; i < 16; i = i + 1) begin : gen_b_zeros
            buf (b_ext[i], gnd);
        end
    endgenerate

    // --- Somador Principal ---
    wire [15:0] sum_out;
    wire cout_out, overflow_out;
    adder_16bit add_inst (
        .a(a_ext),
        .b(b_ext),
        .cin(gnd),
        .sum(sum_out),
        .cout(cout_out),
        .overflow(overflow_out)
    );

    // --- Complemento de 2 (Para obter Valor Absoluto) ---
    wire [15:0] not_sum;
    wire [15:0] twos_comp_sum;
    wire tc_cout, tc_ovf;
    wire [15:0] zero_vec;

    generate
        for(i = 0; i < 16; i = i + 1) begin : gen_inv
            not (not_sum[i], sum_out[i]);
            buf (zero_vec[i], gnd);
        end
    endgenerate

    // Adiciona 1 ao valor invertido usando o seu somador
    adder_16bit abs_adder (
        .a(not_sum),
        .b(zero_vec),
        .cin(vcc),
        .sum(twos_comp_sum),
        .cout(tc_cout),
        .overflow(tc_ovf)
    );

    // --- Multiplexador para escolher Valor Absoluto ---
    wire sign_bit;
    buf (sign_bit, sum_out[15]);
    wire [15:0] abs_val;

    generate
        for(i = 0; i < 16; i = i + 1) begin : gen_mux
            mux2_1 m (.d0(sum_out[i]), .d1(twos_comp_sum[i]), .sel(sign_bit), .y(abs_val[i]));
        end
    endgenerate

    // --- Conversor Binário para BCD (Shift-and-Add-3) ---
    // Como o limite máximo de magnitude é 130, 8 bits são suficientes (abs_val[7:0])
    wire c1_3, c1_2, c1_1, c1_0;
    wire c2_3, c2_2, c2_1, c2_0;
    wire c3_3, c3_2, c3_1, c3_0;
    wire c4_3, c4_2, c4_1, c4_0;
    wire c5_3, c5_2, c5_1, c5_0;
    wire c6_3, c6_2, c6_1, c6_0;
    wire c7_3, c7_2, c7_1, c7_0;

    bcd_add3 m1(.w(gnd),  .x(abs_val[7]), .y(abs_val[6]), .z(abs_val[5]), .a(c1_3), .b(c1_2), .c(c1_1), .d(c1_0));
    bcd_add3 m2(.w(c1_2), .x(c1_1),       .y(c1_0),       .z(abs_val[4]), .a(c2_3), .b(c2_2), .c(c2_1), .d(c2_0));
    bcd_add3 m3(.w(c2_2), .x(c2_1),       .y(c2_0),       .z(abs_val[3]), .a(c3_3), .b(c3_2), .c(c3_1), .d(c3_0));
    bcd_add3 m4(.w(gnd),  .x(c1_3),       .y(c2_3),       .z(c3_3),       .a(c4_3), .b(c4_2), .c(c4_1), .d(c4_0));
    bcd_add3 m5(.w(c3_2), .x(c3_1),       .y(c3_0),       .z(abs_val[2]), .a(c5_3), .b(c5_2), .c(c5_1), .d(c5_0));
    bcd_add3 m6(.w(c4_2), .x(c4_1),       .y(c4_0),       .z(c5_3),       .a(c6_3), .b(c6_2), .c(c6_1), .d(c6_0));
    bcd_add3 m7(.w(c5_2), .x(c5_1),       .y(c5_0),       .z(abs_val[1]), .a(c7_3), .b(c7_2), .c(c7_1), .d(c7_0));

    // --- Instanciação dos Displays de 7 Segmentos ---
    // Unidades
    bcd_7seg_structural disp_u (
        .w(c7_2), .x(c7_1), .y(c7_0), .z(abs_val[0]),
        .a(hex0[0]), .b(hex0[1]), .c(hex0[2]), .d(hex0[3]), .e(hex0[4]), .f(hex0[5]), .g(hex0[6])
    );

    // Dezenas
    bcd_7seg_structural disp_t (
        .w(c6_2), .x(c6_1), .y(c6_0), .z(c7_3),
        .a(hex1[0]), .b(hex1[1]), .c(hex1[2]), .d(hex1[3]), .e(hex1[4]), .f(hex1[5]), .g(hex1[6])
    );

    // Centenas (Recebe apenas o bit ativo c6_3, pois o valor máximo é 130)
    hundreds_7seg_structural disp_c (
        .h0(c6_3),
        .a(hex2[0]), .b(hex2[1]), .c(hex2[2]), .d(hex2[3]), .e(hex2[4]), .f(hex2[5]), .g(hex2[6])
    );

    // Sinal Negativo
    sign_7seg_structural disp_s (
        .sign(sign_bit),
        .a(hex3[0]), .b(hex3[1]), .c(hex3[2]), .d(hex3[3]), .e(hex3[4]), .f(hex3[5]), .g(hex3[6])
    );

endmodule


// Multiplexador 2 para 1 construído com portas
module mux2_1 (
    input d0, input d1, input sel, output y
);
    wire not_sel, a, b;
    not (not_sel, sel);
    and (a, d0, not_sel);
    and (b, d1, sel);
    or  (y, a, b);
endmodule

// Célula Add-3 (Soma 3 se a entrada for > 4)
module bcd_add3(
    input w, x, y, z, // Entradas
    output a, b, c, d // Saídas
);
    wire gt4, w_xy, w_xz, w_or1;
    
    // Circuito lógico combinacional para verificar se Entrada > 4
    and (w_xy, x, y);
    and (w_xz, x, z);
    or  (w_or1, w_xy, w_xz);
    or  (gt4, w, w_or1);

    wire c1, c2, c3;
    supply0 gnd;

    // Bit menos significativo apenas passa direto
    buf (d, z); 
    
    // Reaproveita o full_adder original para somar 0011 ou 0000 estruturalmente
    full_adder fa1 (.a(y), .b(gt4), .cin(gnd), .sum(c), .cout(c1));
    full_adder fa2 (.a(x), .b(gt4), .cin(c1),  .sum(b), .cout(c2));
    full_adder fa3 (.a(w), .b(gnd), .cin(c2),  .sum(a), .cout(c3));
endmodule


module bcd_7seg_structural (
    input w, x, y, z, 
    output a, b, c, d, e, f, g
);
    wire nw, nx, ny, nz;
    not (nw, w);
    not (nx, x);
    not (ny, y);
    not (nz, z);

    // Geração dos mintermos (0 a 9)
    wire m0, m1, m2, m3, m4, m5, m6, m7, m8, m9;
    and (m0, nw, nx, ny, nz);
    and (m1, nw, nx, ny,  z);
    and (m2, nw, nx,  y, nz);
    and (m3, nw, nx,  y,  z);
    and (m4, nw,  x, ny, nz);
    and (m5, nw,  x, ny,  z);
    and (m6, nw,  x,  y, nz);
    and (m7, nw,  x,  y,  z);
    and (m8,  w, nx, ny, nz);
    and (m9,  w, nx, ny,  z);

    // Lógica ativa em zero (comum em placas FPGAs) construída com portas NOR
    nor (a, m0, m2, m3, m5, m6, m7, m8, m9);
    nor (b, m0, m1, m2, m3, m4, m7, m8, m9);
    nor (c, m0, m1, m3, m4, m5, m6, m7, m8, m9);
    nor (d, m0, m2, m3, m5, m6, m8, m9);
    nor (e, m0, m2, m6, m8);
    nor (f, m0, m4, m5, m6, m8, m9);
    nor (g, m2, m3, m4, m5, m6, m8, m9);
endmodule

module hundreds_7seg_structural (
    input h0, output a, b, c, d, e, f, g
);
    supply1 vcc;
    buf (a, vcc);
    not (b, h0); // Segmento aceso (0) se for centena
    not (c, h0); 
    buf (d, vcc);
    buf (e, vcc);
    buf (f, vcc);
    buf (g, vcc);
endmodule

module sign_7seg_structural (
    input sign, output a, b, c, d, e, f, g
);
    supply1 vcc;
    buf (a, vcc);
    buf (b, vcc);
    buf (c, vcc);
    buf (d, vcc);
    buf (e, vcc);
    buf (f, vcc);
    not (g, sign); // Ativa o traço do meio se sinal for 1
endmodule


