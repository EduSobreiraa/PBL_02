module full_adder (
    input  wire a,
    input  wire b,
    input  wire cin,
    output wire sum,
    output wire cout
);

    // Sinais internos de conexão
    wire w_sum1;
    wire w_c1;
    wire w_c2;

    // Instanciação do primeiro Half Adder
    half_adder ha1 (
        .a(a),
        .b(b),
        .sum(w_sum1),
        .carry(w_c1)
    );

    // Instanciação do segundo Half Adder
    half_adder ha2 (
        .a(w_sum1),
        .b(cin),
        .sum(sum),
        .carry(w_c2)
    );

    // Porta OR para determinar o carry out
    or g_or (cout, w_c1, w_c2);

endmodule