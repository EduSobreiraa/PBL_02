//+3, Double Dabble
module bcd_add3(
    input w, x, y, z, output a, b, c, d
);
    wire gt4, w_xy, w_xz, w_or1;
    
    // Identificação de valores >= 5
    and (w_xy, x, y);        // valores 6 e 7 
    and (w_xz, x, z);        //  valor 5
    or (w_or1, w_xy, w_xz);  // Unifica condições para valores 5, 6 e 7
    or (gt4, w, w_or1);      // gt4 fica em 1 se for >= 5 (8 e 9)
    
    wire c0, c1, c2, c3;
    supply0 gnd;
    
    // Soma condicional da constante 3, caso gt4 == 1
    full_adder fa0 (.a(z), .b(gt4), .cin(gnd), .sum(d), .cout(c0)); // 1
    full_adder fa1 (.a(y), .b(gt4), .cin(c0),  .sum(c), .cout(c1)); // 1
    full_adder fa2 (.a(x), .b(gnd), .cin(c1),  .sum(b), .cout(c2)); // 0
    full_adder fa3 (.a(w), .b(gnd), .cin(c2),  .sum(a), .cout(c3)); // 0
endmodule

//ajusta os 5 dígitos BCD e faz o deslocamento pela fiação
module bcd_step (
    input [19:0] pre, input y_bit, output [19:0] next_pre
);
    // pre[2:0] com y_bit desloca os fios 1 pino para a esquerda simultaneamente ao ajuste +3
    bcd_add3 a0 (.w(pre[2]),  .x(pre[1]),  .y(pre[0]),  .z(y_bit),   .a(next_pre[3]),  .b(next_pre[2]),  .c(next_pre[1]),  .d(next_pre[0]));  // Dígito 0 (Unidades)
    bcd_add3 a1 (.w(pre[6]),  .x(pre[5]),  .y(pre[4]),  .z(pre[3]),   .a(next_pre[7]),  .b(next_pre[6]),  .c(next_pre[5]),  .d(next_pre[4]));  // Dígito 1 (Dezenas)
    bcd_add3 a2 (.w(pre[10]), .x(pre[9]),  .y(pre[8]),  .z(pre[7]),   .a(next_pre[11]), .b(next_pre[10]), .c(next_pre[9]), .d(next_pre[8]));  // Dígito 2 (Centenas)
    bcd_add3 a3 (.w(pre[14]), .x(pre[13]), .y(pre[12]), .z(pre[11]),  .a(next_pre[15]), .b(next_pre[14]), .c(next_pre[13]), .d(next_pre[12])); // Dígito 3 (Milhares)
    bcd_add3 a4 (.w(pre[18]), .x(pre[17]), .y(pre[16]), .z(pre[15]),  .a(next_pre[19]), .b(next_pre[18]), .c(next_pre[17]), .d(next_pre[16])); // Dígito 4 (Dezenas de Milhar)
endmodule

// Conversor completo de Binário, para BCD em cascata combinacional
module bin_to_bcd_16 (
    input [15:0] bin_in, output [19:0] bcd_out
);
    supply0 gnd;
    wire [19:0] pre1, pre2, pre3, pre4, pre5, pre6, pre7, pre8, pre9, pre10, pre11, pre12, pre13, pre14;
    wire dummy_out; // Descarta o bit sobressalente de estouro no último shift

    // Injeta os bits do MSB (bit 15) até o bit 1 ao longo de 15 passos bcd_step em cadeia
    bcd_step st0  (.pre({gnd, gnd, gnd, gnd, gnd, gnd, gnd, gnd, gnd, gnd, gnd, gnd, gnd, gnd, gnd, gnd, gnd, gnd, gnd, gnd}), .y_bit(bin_in[15]), .next_pre(pre1));
    bcd_step st1  (.pre(pre1),  .y_bit(bin_in[14]), .next_pre(pre2));
    bcd_step st2  (.pre(pre2),  .y_bit(bin_in[13]), .next_pre(pre3));
    bcd_step st3  (.pre(pre3),  .y_bit(bin_in[12]), .next_pre(pre4));
    bcd_step st4  (.pre(pre4),  .y_bit(bin_in[11]), .next_pre(pre5));
    bcd_step st5  (.pre(pre5),  .y_bit(bin_in[10]), .next_pre(pre6));
    bcd_step st6  (.pre(pre6),  .y_bit(bin_in[9]),  .next_pre(pre7));
    bcd_step st7  (.pre(pre7),  .y_bit(bin_in[8]),  .next_pre(pre8));
    bcd_step st8  (.pre(pre8),  .y_bit(bin_in[7]),  .next_pre(pre9));
    bcd_step st9  (.pre(pre9),  .y_bit(bin_in[6]),  .next_pre(pre10));
    bcd_step st10 (.pre(pre10), .y_bit(bin_in[5]),  .next_pre(pre11));
    bcd_step st11 (.pre(pre11), .y_bit(bin_in[4]),  .next_pre(pre12));
    bcd_step st12 (.pre(pre12), .y_bit(bin_in[3]),  .next_pre(pre13));
    bcd_step st13 (.pre(pre13), .y_bit(bin_in[2]),  .next_pre(pre14));
    
    // Passo final do algoritmo (bit 1)
    bcd_step st14 (.pre(pre14), .y_bit(bin_in[1]),  .next_pre({dummy_out, bcd_out[19:1]}));
    
    // O LSB passa direto sem precisar de alteração
    or pass_b0 (bcd_out[0], bin_in[0], gnd);
endmodule

// Decodificador de BCD, para Display de 7 Segmentos
module bcd_7seg (
    input w, x, y, z, output a, b, c, d, e, f, g
);
    wire nw, nx, ny, nz;
    // Inversão das entradas de 4 bits para permitir o mapeamento dos mintermos
    not (nw, w); not (nx, x); not (ny, y); not (nz, z);
    
    wire m0, m1, m2, m3, m4, m5, m6, m7, m8, m9;
    // Matriz de mintermos para os 10 dígitos decimais
    and (m0, nw, nx, ny, nz); 
    and (m1, nw, nx, ny, z);  
    and (m2, nw, nx, y, nz);  
    and (m3, nw, nx, y, z);   
    and (m4, nw, x, ny, nz);  
    and (m5, nw, x, ny, z);   
    and (m6, nw, x, y, nz);   
    and (m7, nw, x, y, z);    
    and (m8, w, nx, ny, nz);  
    and (m9, w, nx, ny, z);   
    
    // Mapeamento dos segmentos (a-g) usando NOR para sinalizar ativo em 0 
    nor (a, m0, m2, m3, m5, m6, m7, m8, m9);
    nor (b, m0, m1, m2, m3, m4, m7, m8, m9);
    nor (c, m0, m1, m3, m4, m5, m6, m7, m8, m9);
    nor (d, m0, m2, m3, m5, m6, m8, m9);
    nor (e, m0, m2, m6, m8);
    nor (f, m0, m4, m5, m6, m8, m9);
    nor (g, m2, m3, m4, m5, m6, m8, m9);
endmodule