module half_adder (
    input  wire a,
    input  wire b,
    output wire sum,
    output wire carry
);

    // Instanciação de portas lógicas primitivas
    xor g_xor (sum, a, b);
    and g_and (carry, a, b);

endmodule

