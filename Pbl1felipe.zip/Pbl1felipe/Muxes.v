module mux2_1 (
    input d0, input d1, input sel, output y
);
    wire not_sel, a, b;
    not (not_sel, sel);
    and (a, d0, not_sel);
    and (b, d1, sel);
    or (y, a, b);
endmodule

module mux_7bit (
    input [6:0] d0, //Padrão em Decimal 
    input [6:0] d1, //Padrão em Hexadecimal
    input sel,
    output [6:0] y
);
    mux2_1 m0 (.d0(d0[0]), .d1(d1[0]), .sel(sel), .y(y[0]));
    mux2_1 m1 (.d0(d0[1]), .d1(d1[1]), .sel(sel), .y(y[1]));
    mux2_1 m2 (.d0(d0[2]), .d1(d1[2]), .sel(sel), .y(y[2]));
    mux2_1 m3 (.d0(d0[3]), .d1(d1[3]), .sel(sel), .y(y[3]));
    mux2_1 m4 (.d0(d0[4]), .d1(d1[4]), .sel(sel), .y(y[4]));
    mux2_1 m5 (.d0(d0[5]), .d1(d1[5]), .sel(sel), .y(y[5]));
    mux2_1 m6 (.d0(d0[6]), .d1(d1[6]), .sel(sel), .y(y[6]));
endmodule

//Complemento de 2 ou positivo
module abs_16bit (
    input [15:0] in_val, output [15:0] out_abs //in_val é só a entrada
);
    supply0 gnd; supply1 vcc;
    wire [15:0] not_y, y_neg; // y_neg = in_val negativo

//Inversão dos bits
    not (not_y[0], in_val[0]); not (not_y[1], in_val[1]); not (not_y[2], in_val[2]); not (not_y[3], in_val[3]);
    not (not_y[4], in_val[4]); not (not_y[5], in_val[5]); not (not_y[6], in_val[6]); not (not_y[7], in_val[7]);
    not (not_y[8], in_val[8]); not (not_y[9], in_val[9]); not (not_y[10], in_val[10]); not (not_y[11], in_val[11]);
    not (not_y[12], in_val[12]); not (not_y[13], in_val[13]); not (not_y[14], in_val[14]); not (not_y[15], in_val[15]);

// soma de +1 ao valor invertido
    adder_16bit abs_adder_y  (
        .a(not_y), 
        .b({gnd, gnd, gnd, gnd, gnd, gnd, gnd, gnd, gnd, gnd, gnd, gnd, gnd, gnd, gnd, gnd}), 
		   
			//entrega para o adder de 16 bits o cin garantido como 1 e todos os outros valores como zero, o adder devolve o valor depois do complemento de 2
        .cin(vcc), .sum(y_neg)
    );

//mux seleciona qual valor será passado aos outros módulos, bit15 = 1, passa o o y_neg, caso bit15 = 0, passa o valor original 
    mux2_1 m_y0  (.d0(in_val[0]),  .d1(y_neg[0]),  .sel(in_val[15]), .y(out_abs[0]));
    mux2_1 m_y1  (.d0(in_val[1]),  .d1(y_neg[1]),  .sel(in_val[15]), .y(out_abs[1]));
    mux2_1 m_y2  (.d0(in_val[2]),  .d1(y_neg[2]),  .sel(in_val[15]), .y(out_abs[2]));
    mux2_1 m_y3  (.d0(in_val[3]),  .d1(y_neg[3]),  .sel(in_val[15]), .y(out_abs[3]));
    mux2_1 m_y4  (.d0(in_val[4]),  .d1(y_neg[4]),  .sel(in_val[15]), .y(out_abs[4]));
    mux2_1 m_y5  (.d0(in_val[5]),  .d1(y_neg[5]),  .sel(in_val[15]), .y(out_abs[5]));
    mux2_1 m_y6  (.d0(in_val[6]),  .d1(y_neg[6]),  .sel(in_val[15]), .y(out_abs[6]));
    mux2_1 m_y7  (.d0(in_val[7]),  .d1(y_neg[7]),  .sel(in_val[15]), .y(out_abs[7]));
    mux2_1 m_y8  (.d0(in_val[8]),  .d1(y_neg[8]),  .sel(in_val[15]), .y(out_abs[8]));
    mux2_1 m_y9  (.d0(in_val[9]),  .d1(y_neg[9]),  .sel(in_val[15]), .y(out_abs[9]));
    mux2_1 m_y10 (.d0(in_val[10]), .d1(y_neg[10]), .sel(in_val[15]), .y(out_abs[10]));
    mux2_1 m_y11 (.d0(in_val[11]), .d1(y_neg[11]), .sel(in_val[15]), .y(out_abs[11]));
    mux2_1 m_y12 (.d0(in_val[12]), .d1(y_neg[12]), .sel(in_val[15]), .y(out_abs[12]));
    mux2_1 m_y13 (.d0(in_val[13]), .d1(y_neg[13]), .sel(in_val[15]), .y(out_abs[13]));
    mux2_1 m_y14 (.d0(in_val[14]), .d1(y_neg[14]), .sel(in_val[15]), .y(out_abs[14]));
    mux2_1 m_y15 (.d0(in_val[15]), .d1(y_neg[15]), .sel(in_val[15]), .y(out_abs[15]));
endmodule

